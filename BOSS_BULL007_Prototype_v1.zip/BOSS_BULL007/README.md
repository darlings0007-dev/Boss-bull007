# BOSS BULL007 — Prototype v1

## What it is
A local Streamlit dashboard for educational NSE/BSE-style paper-trading experiments. It uses synthetic demo data unless you upload a historical OHLCV CSV. It does not connect to a broker, fetch live market data, or place orders.

## Run on a computer
1. Install Python 3.10 or newer from https://www.python.org/downloads/
2. Extract this folder.
3. Open a terminal/command prompt in this folder.
4. Install dependencies:
   `python -m pip install -r requirements.txt`
5. Start the app:
   `python -m streamlit run app.py`
6. Open the local URL shown in the terminal (usually http://localhost:8501).

## CSV format
Required columns: Date, Open, High, Low, Close. Volume is optional.
Use historical data you are authorized to access. The app does not retrieve market data itself.

## Safety
- Prototype only; no live execution.
- Signals are not investment advice and are not evidence of profitability.
- The position-sizing example excludes fees, taxes, slippage, gaps, liquidity, and exchange/broker constraints.
- Test strategies with realistic costs and out-of-sample data before considering real-money trading.
