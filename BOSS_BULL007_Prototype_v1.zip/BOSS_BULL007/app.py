import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path

st.set_page_config(page_title="BOSS BULL007", page_icon="🐂", layout="wide")

st.title("🐂 BOSS BULL007")
st.caption("NSE/BSE Intraday Paper-Trading Lab • Prototype v1 • No real orders")

st.warning(
    "Educational simulator only. This app does not connect to NSE/BSE or a broker, "
    "does not provide live prices, and never places real orders. Sample data is synthetic."
)

with st.sidebar:
    st.header("Risk Controls")
    capital = st.number_input("Virtual capital (₹)", min_value=1000, max_value=10000000, value=100000, step=5000)
    risk_pct = st.slider("Risk per trade (%)", min_value=0.1, max_value=2.0, value=0.5, step=0.1)
    daily_loss_pct = st.slider("Daily loss limit (%)", min_value=0.5, max_value=5.0, value=2.0, step=0.5)
    stop_pct = st.slider("Stop-loss distance (%)", min_value=0.2, max_value=3.0, value=1.0, step=0.1)
    fast_period = st.slider("Fast moving average", 3, 20, 5)
    slow_period = st.slider("Slow moving average", 10, 60, 20)
    st.caption("Use fast MA < slow MA for sensible crossover settings.")

def synthetic_data(n=250, seed=7):
    rng = np.random.default_rng(seed)
    dates = pd.date_range(end=pd.Timestamp.today().normalize(), periods=n, freq="B")
    returns = rng.normal(0.0004, 0.012, n)
    close = 500 * np.exp(np.cumsum(returns))
    open_ = np.r_[close[0], close[:-1]] * (1 + rng.normal(0, 0.003, n))
    high = np.maximum(open_, close) * (1 + rng.uniform(0.001, 0.012, n))
    low = np.minimum(open_, close) * (1 - rng.uniform(0.001, 0.012, n))
    volume = rng.integers(10000, 500000, n)
    return pd.DataFrame({"Date": dates, "Open": open_, "High": high, "Low": low, "Close": close, "Volume": volume})

def normalize_upload(df):
    df = df.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]
    aliases = {"date": "Date", "datetime": "Date", "timestamp": "Date",
               "open": "Open", "high": "High", "low": "Low",
               "close": "Close", "adj close": "Close", "volume": "Volume"}
    df = df.rename(columns={c: aliases[c] for c in df.columns if c in aliases})
    required = ["Date", "Open", "High", "Low", "Close"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    for col in ["Open", "High", "Low", "Close"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    if "Volume" not in df.columns:
        df["Volume"] = 0
    df["Volume"] = pd.to_numeric(df["Volume"], errors="coerce").fillna(0)
    df = df.dropna(subset=required).sort_values("Date").drop_duplicates("Date")
    if len(df) < 5:
        raise ValueError("Please provide at least 5 valid rows.")
    return df.reset_index(drop=True)

st.subheader("1. Choose your data")
uploaded = st.file_uploader("Upload historical OHLCV CSV (optional)", type=["csv"])
symbol = st.text_input("Symbol label", value="DEMO")
if uploaded:
    try:
        data = normalize_upload(pd.read_csv(uploaded))
        data_source = "Uploaded CSV"
    except Exception as e:
        st.error(f"Could not read CSV: {e}")
        st.stop()
else:
    data = synthetic_data()
    data_source = "Synthetic demo data (not real market prices)"

if fast_period >= slow_period:
    st.error("Fast moving average must be shorter than the slow moving average.")
    st.stop()

data["FastMA"] = data["Close"].rolling(fast_period).mean()
data["SlowMA"] = data["Close"].rolling(slow_period).mean()
data["CrossUp"] = (data["FastMA"] > data["SlowMA"]) & (data["FastMA"].shift(1) <= data["SlowMA"].shift(1))
data["CrossDown"] = (data["FastMA"] < data["SlowMA"]) & (data["FastMA"].shift(1) >= data["SlowMA"].shift(1))
data["Signal"] = np.select([data["CrossUp"], data["CrossDown"]], ["BUY candidate", "EXIT candidate"], default="WAIT")

latest = data.iloc[-1]
c1, c2, c3, c4 = st.columns(4)
c1.metric("Symbol", symbol.upper())
c2.metric("Latest close", f"₹{latest['Close']:,.2f}")
c3.metric("Fast MA", "—" if pd.isna(latest["FastMA"]) else f"₹{latest['FastMA']:,.2f}")
c4.metric("Current signal", latest["Signal"])

st.caption(f"Data source: {data_source}. Signals are educational examples, not recommendations.")
chart_df = data.set_index("Date")[["Close", "FastMA", "SlowMA"]]
st.line_chart(chart_df, height=320)

st.subheader("2. Paper-trading risk calculator")
price = float(latest["Close"])
risk_rupees = capital * (risk_pct / 100)
stop_distance = price * (stop_pct / 100)
qty_by_risk = int(risk_rupees // stop_distance) if stop_distance > 0 else 0
qty_by_cash = int(capital // price) if price > 0 else 0
quantity = max(0, min(qty_by_risk, qty_by_cash))
planned_loss = quantity * stop_distance
daily_limit = capital * (daily_loss_pct / 100)

a, b, c, d = st.columns(4)
a.metric("Risk budget / trade", f"₹{risk_rupees:,.2f}")
b.metric("Estimated quantity", f"{quantity:,} shares")
c.metric("Planned stop loss", f"₹{planned_loss:,.2f}")
d.metric("Daily loss limit", f"₹{daily_limit:,.2f}")

st.info(
    "Sizing illustration assumes a simple long position and a percentage stop. "
    "It excludes brokerage, taxes, slippage, gaps, liquidity and lot-size rules. "
    "Actual losses can exceed the estimate."
)

st.subheader("3. Recent signals")
show_cols = ["Date", "Open", "High", "Low", "Close", "Volume", "FastMA", "SlowMA", "Signal"]
st.dataframe(data[show_cols].tail(25).sort_values("Date", ascending=False), use_container_width=True)

st.subheader("4. Download results")
csv = data[show_cols].to_csv(index=False).encode("utf-8")
st.download_button("Download signals CSV", csv, file_name=f"{symbol.lower()}_boss_bull007_signals.csv", mime="text/csv")

with st.expander("CSV format for your own historical data"):
    st.write("Your CSV needs columns named Date, Open, High, Low, Close. Volume is optional.")
    st.code("Date,Open,High,Low,Close,Volume\n2026-01-05,100,103,99,102,150000\n2026-01-06,102,104,101,103,175000", language="csv")

st.subheader("5. Agent status")
agent_rows = [
    ("Market Researcher", "Basic price-data scan", "Prototype"),
    ("News Analyst", "Not connected; no headlines are fabricated", "Planned"),
    ("Strategy Architect", "Moving-average crossover example", "Prototype"),
    ("Quant Coder", "Indicator calculations and CSV export", "Prototype"),
    ("Risk Manager", "Position-size estimate and loss limits", "Basic"),
    ("BOSS Coordinator", "Single dashboard; multi-agent orchestration not yet implemented", "Planned"),
]
st.table(pd.DataFrame(agent_rows, columns=["Agent", "Function", "Status"]))

st.caption("Next upgrade: validated historical intraday data, realistic backtesting with fees/slippage, paper trade ledger, and only then optional broker API integration.")
